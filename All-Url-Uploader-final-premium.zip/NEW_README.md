add your suggestion to write better readme and docs site
